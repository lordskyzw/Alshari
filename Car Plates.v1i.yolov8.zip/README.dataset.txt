# Car Plates > 2023-12-26 11:58pm
https://universe.roboflow.com/myfirstworkspace-v9prk/car-plates-ftgfh

Provided by a Roboflow user
License: CC BY 4.0

